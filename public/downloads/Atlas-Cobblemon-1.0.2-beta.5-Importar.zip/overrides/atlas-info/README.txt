ATLAS COBBLEMON 1.0.2-beta.5 — PERFIL IMPORTÁVEL
Minecraft Java 1.21.1 | Fabric Loader 0.18.0 | Java 21 | 58 mods

1. Crie uma instância separada importando este ZIP no seu launcher compatível
   com manifest.json do CurseForge (por exemplo, Prism Launcher: Adicionar
   instância > Importar). Mantenha o ZIP inteiro durante a importação.
2. O launcher baixa os mods oficiais referenciados no manifest.json e copia
   os mods complementares de overrides/mods. Não copie este ZIP na pasta mods.
3. Selecione Java 21. Recomendamos 4 GB de RAM disponíveis para o jogo;
   ajuste ao seu computador, sem reservar toda a memória para o Minecraft.
4. Abra a instância e conecte a stapling-gpo.tun.ply.gg.
   Aceite o pacote de recursos oferecido pelo servidor.

Este download é uma alternativa ao Atlas Launcher. Não inclui Minecraft,
Java ou conta. O seu launcher precisa preparar o jogo e o Fabric.
Não atualiza automaticamente: para uma nova versão, importe o novo pacote
em outra instância e preserve seus mundos/configurações pessoais.

As versões e os hashes dos 58 mods correspondem ao catálogo atual do Atlas
Launcher. Battle Positions e Atlas Interface estão incluídos.
Perfil distribuído pelo site Atlas; não representa aprovação da moderação
CurseForge. Créditos de terceiros preservados em atlas-info/CREDITS.md.
Sem mundos do servidor, senhas, tokens ou arquivos administrativos.
Site: https://www.atlascobblemon.com.br
