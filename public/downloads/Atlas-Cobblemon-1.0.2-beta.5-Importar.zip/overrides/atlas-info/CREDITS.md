# Atlas Cobblemon — Credits / Créditos

Minecraft 1.21.1 · Fabric Loader 0.18.0 · Java 21

Mods remain licensed by their respective authors. Atlas ownership does not override third-party licenses.

## Approved external mods / Mods externos aprovados

Checked on 25 October 2026 against the list linked by CurseForge:
https://docs.google.com/spreadsheets/d/176Wv-PZUo9hFxy6oC6N8tWdquBLPRtSuLbNK-r0_byM/edit

### cobblemon-additions
Authors: Strikebyte, IronboundJam03, PeculiarSana, Nezmir
Version: 4.1.6
License declared in the official JAR: CC0-1.0
Official file: https://modrinth.com/mod/cobblemon-additions/version/degN5DK4

### cobbreeding
Authors: Ludichat, Fuzuki
Version: 2.2.0
License declared in the official JAR: MIT
Official file: https://modrinth.com/mod/cobbreeding/version/DcOPx56X

### tmcraft
Authors: KiwiFlavoredApollo
Version: 1.4.19+1.8.2
License declared in the official JAR: GPL-3.0
Official file: https://modrinth.com/mod/tmcraft/version/cIXTptDr

## All included mods / Todos os mods

- Accessories: https://www.curseforge.com/minecraft/mc-mods/accessories
- Architectury: https://www.curseforge.com/minecraft/mc-mods/architectury-api
- Athena: https://www.curseforge.com/minecraft/mc-mods/athena
- Better Third Person: https://www.curseforge.com/minecraft/mc-mods/better-third-person
- BetterF3: https://www.curseforge.com/minecraft/mc-mods/betterf3
- COBBLEVERSE Badges: https://www.curseforge.com/minecraft/mc-mods/cobbleverse-badges
- Catch Indicator: https://www.curseforge.com/minecraft/mc-mods/catch-indicator
- Cloth Config v15: https://www.curseforge.com/minecraft/mc-mods/cloth-config
- CobbleCuisine: https://www.curseforge.com/minecraft/mc-mods/cobblecuisine
- CobbleDollars: https://www.curseforge.com/minecraft/mc-mods/cobbledollars
- CobbleFurnies: https://www.curseforge.com/minecraft/mc-mods/cobblefurnies
- Cobblemon: https://www.curseforge.com/minecraft/mc-mods/cobblemon
- Cobblemon Additions: https://modrinth.com/mod/cobblemon-additions/version/degN5DK4
- Cobblemon Battle Extras: https://www.curseforge.com/minecraft/mc-mods/cobblemon-battle-extras
- Cobblemon Catch Rate Display: https://www.curseforge.com/minecraft/mc-mods/cobblemon-catch-rate-display
- Cobblemon Raid Dens: https://www.curseforge.com/minecraft/mc-mods/cobblemonraiddens
- Cobblemon: Mega Showdown: https://www.curseforge.com/minecraft/mc-mods/cobblemon-mega-showdown
- Cobblenav: https://www.curseforge.com/minecraft/mc-mods/cobblemon-pokenav
- Cobbreeding: https://modrinth.com/mod/cobbreeding/version/DcOPx56X
- Controlling: https://www.curseforge.com/minecraft/mc-mods/controlling
- Dynamic FPS: https://www.curseforge.com/minecraft/mc-mods/dynamic-fps
- Easy NPC: https://www.curseforge.com/minecraft/mc-mods/easy-npc-core
- EntityCulling: https://www.curseforge.com/minecraft/mc-mods/entityculling
- Fabric API: https://www.curseforge.com/minecraft/mc-mods/fabric-api
- Fabric Language Kotlin: https://www.curseforge.com/minecraft/mc-mods/fabric-language-kotlin
- FerriteCore: https://www.curseforge.com/minecraft/mc-mods/ferritecore-fabric
- Forge Config API Port: https://www.curseforge.com/minecraft/mc-mods/forge-config-api-port
- GeckoLib 4: https://www.curseforge.com/minecraft/mc-mods/geckolib
- ImmediatelyFast: https://www.curseforge.com/minecraft/mc-mods/immediatelyfast
- Just Enough Items: https://www.curseforge.com/minecraft/mc-mods/jei
- Krypton: https://www.curseforge.com/minecraft/mc-mods/krypton
- Litematica: https://www.curseforge.com/minecraft/mc-mods/project-1205459
- Lithium: https://www.curseforge.com/minecraft/mc-mods/lithium
- MaLiLib: https://www.curseforge.com/minecraft/mc-mods/malilib
- ModernFix: https://www.curseforge.com/minecraft/mc-mods/modernfix
- More Culling: https://www.curseforge.com/minecraft/mc-mods/moreculling
- MoreCobblemonTweaks: https://www.curseforge.com/minecraft/mc-mods/morecobblemontweaks
- Mouse Tweaks: https://www.curseforge.com/minecraft/mc-mods/mouse-tweaks
- NotEnoughAnimations: https://www.curseforge.com/minecraft/mc-mods/not-enough-animations
- Only Bottle Caps: https://www.curseforge.com/minecraft/mc-mods/only-bottle-caps
- Packet Fixer: https://www.curseforge.com/minecraft/mc-mods/packet-fixer
- PastureLoot: https://www.curseforge.com/minecraft/mc-mods/cobblemon-pasture-loot
- Pokeblocks: https://www.curseforge.com/minecraft/mc-mods/pokeblocks
- Radical Cobblemon Trainers API: https://www.curseforge.com/minecraft/mc-mods/radical-cobblemon-trainers-api
- Safe Pastures: https://www.curseforge.com/minecraft/mc-mods/cobblemon-safepastures
- Searchables: https://www.curseforge.com/minecraft/mc-mods/searchables
- Sodium: https://www.curseforge.com/minecraft/mc-mods/sodium
- SuperMartijn642's Config Lib: https://www.curseforge.com/minecraft/mc-mods/supermartijn642s-config-lib
- SuperMartijn642's Core Lib: https://www.curseforge.com/minecraft/mc-mods/supermartijn642s-core-lib
- TM Craft: https://modrinth.com/mod/tmcraft/version/cIXTptDr
- WorldEdit: https://www.curseforge.com/minecraft/mc-mods/worldedit
- Xaero's Minimap: https://www.curseforge.com/minecraft/mc-mods/xaeros-minimap
- YetAnotherConfigLib: https://www.curseforge.com/minecraft/mc-mods/yacl
- Zoomify: https://www.curseforge.com/minecraft/mc-mods/zoomify
- oωo: https://www.curseforge.com/minecraft/mc-mods/owo-lib
- zamega: https://www.curseforge.com/minecraft/mc-mods/navas-za-megas
## Additional site profile components

Cobblemon Battle Positions: Ramen, MIT. Original license bundled in licenses/.
Atlas Interface 1.1.3: Atlas Cobblemon.
